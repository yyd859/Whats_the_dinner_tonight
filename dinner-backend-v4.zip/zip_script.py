
import zipfile
import os
import sys

def zip_folder(folder_path, output_path):
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            if 'node_modules' in root or '.git' in root:
                continue
            for file in files:
                if file.endswith('.zip') or file.endswith('.log'):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, folder_path)
                # 强制使用正斜杠
                arcname = arcname.replace(os.path.sep, '/')
                zipf.write(file_path, arcname)
                print(f"Adding {arcname}")

if __name__ == "__main__":
    zip_folder('.', '../dinner-backend-v4.zip')
